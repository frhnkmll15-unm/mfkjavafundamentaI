package com.juaracoding.mfkjavafundamental.testharian.Test;/*
Created By IntelliJ IDEA 2022.1.3 (Community Edition)
Build #IC-221.5921.22, built on June 21, 2022
@Author Farhan a.k.a Muhammad Farhan Kamil
Java Developer
Created On 06/04/2023 23:04
@Last Modified 06/04/2023 23:04
Version 1.0
*/



public class OperatorGabungan {
	public static void main(String[] args) {
		int a =10, b =10, c =10,d =10, e =10, f=10;
		System.out.println("Variabel a, b, c, d, e, f = 10\n");
		a +=5;
		System.out.println("Hasil operasi a += 5: "+ a);
		b -=3;
		System.out.println("Hasil operasi b -= 3: "+ b);
		c *=3;
		System.out.println("Hasil operasi c *= 3: "+ c);
		d /=3;
		System.out.println("Hasil operasi d /= 3: "+ d);
		e %=3;
		System.out.println("Hasil Operasi e %= 3: "+ e);
		f <<=2;
		System.out.println("Hasil operasi f <<= 2: "+ f);
	}
}
