package com.juaracoding.mfkjavafundamental;

public enum TestTemplateEnum {
}
/*
Created By IntelliJ IDEA 2022.2.3 (Community Edition)
Build #IU-222.4345.14, built on October 5, 2022
@Author Administrator a.k.a. Muhammad Farhan Kamil
Java Developer
Created on 1/12/2023 7:51 PM
@Last Modified 1/12/2023 7:51 PM
Version 1.0
*/